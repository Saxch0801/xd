// Importar dependencias
const express = require('express');
const mysql = require('mysql');
const path = require('path');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const session = require('express-session');
require('dotenv').config();

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cookieParser());
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: false,
        maxAge: 1000 * 60 * 60 * 24// 1 dia
    }
}));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    // password: 'Pandini09',
    //password: 'Oinotna123',
    password: 'n0m3l0',
    database: 'LaDesesperanza'
});

db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conexión exitosa a la base de datos');
});

// 1. Obtener todos los productos con el nombre de la categoría
app.get('/productos', (req, res) => {
    const query = `
        SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.stock, p.id_categoria, p.imagen_url, c.nombre_categoria
        FROM Productos p
        INNER JOIN Categorias c ON p.id_categoria = c.id_categoria
    `;
    
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).json({ error: 'Error al obtener productos' });
        } else {
            res.json(results);
        }
    });
});

// 2. Obtener un producto por ID
app.get('/productos/:id', (req, res) => {
    const id = req.params.id;
    const query = `
        SELECT p.id_producto, p.nombre, p.descripcion, p.precio, p.stock, p.id_categoria, p.imagen_url, c.nombre_categoria
        FROM Productos p
        INNER JOIN Categorias c ON p.id_categoria = c.id_categoria
        WHERE p.id_producto = ?`;

    db.query(query, [id], (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al obtener el producto' });
        } else if (result.length === 0) {
            res.status(404).json({ error: 'Producto no encontrado' });
        } else {
            res.json(result[0]); // Esto ahora incluirá el nombre de la categoría
        }
    });
});

// 3. Agregar un nuevo producto
app.post('/addProductos', (req, res) => {
    const { nombre, descripcion, precio, stock, id_categoria, imagen_url, imagen } = req.body;
    console.log('Datos recibidos:', req.body); // Agrega esto para depurar
    const sql = 'INSERT INTO Productos (nombre, descripcion, precio, stock, id_categoria, imagen_url, imagen) VALUES (?, ?, ?, ?, ?, ?, ?)';
    db.query(sql, [nombre, descripcion, precio, stock, id_categoria, imagen_url, imagen], (err, result) => {
        if (err) {
            console.error('Error al agregar el producto:', err); // Agrega esto para ver el error
            res.status(500).json({ error: 'Error al agregar el producto' });
        } else {
            res.status(201).json({ message: 'Producto agregado', id: result.insertId });
        }
    });
});

// Obtener todas las categorías del producto
app.get('/categorias', (req, res) => {
    db.query('SELECT * FROM Categorias', (err, results) => {
        if (err) {
            res.status(500).json({ error: 'Error al obtener categorías' });
        } else {
            res.json(results);
        }
    });
});


// 4. Actualizar un producto por ID
app.put('/updateProductos/:id', (req, res) => {
    const id = req.params.id;
    const { nombre, descripcion, precio, stock, id_categoria, imagen_url, imagen } = req.body;
    const sql = 'UPDATE Productos SET nombre = ?, descripcion = ?, precio = ?, stock = ?, id_categoria = ?, imagen_url = ?, imagen = ? WHERE id_producto = ?';
    db.query(sql, [nombre, descripcion, precio, stock, id_categoria, imagen_url, imagen, id], (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al actualizar el producto' });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ error: 'Producto no encontrado' });
        } else {
            res.json({ message: 'Producto actualizado' });
        }
    });
});

// 5. Eliminar un producto por ID
app.delete('/deleteProductos/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM Productos WHERE id_producto = ?', [id], (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al eliminar el producto' });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ error: 'Producto no encontrado' });
        } else {
            res.json({ message: 'Producto eliminado' });
        }
    });
});

// 1. Obtener todos los usuarios
app.get('/usuarios', (req, res) => {
    db.query('SELECT * FROM Usuarios', (err, results) => {
        if (err) {
            res.status(500).json({ error: 'Error al obtener usuarios' });
        } else {
            res.json(results);
        }
    });
});

// 2. Obtener un usuario por ID
app.get('/usuarios/:id', (req, res) => {
    const id = req.params.id;
    db.query('SELECT * FROM Usuarios WHERE id_usuario = ?', [id], (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al obtener el usuario' });
        } else if (result.length === 0) {
            res.status(404).json({ error: 'Usuario no encontrado' });
        } else {
            res.json(result[0]);
        }
    });
});

// 3. Agregar un nuevo usuario
app.post('/signupUsuario', (req, res) => {
    const { nombre_usuario, email, contraseña, rol } = req.body;
    const sql = 'INSERT INTO Usuarios (nombre_usuario, email, contraseña, rol) VALUES (?, ?, ?, ?)';
    db.query(sql, [nombre_usuario, email, contraseña, rol], (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al agregar el usuario' });
        } else {
            res.status(201).json({ message: 'Usuario agregado', id: result.insertId });
        }
    });
});

// 4. Actualizar un usuario por ID
app.put('/updateUsuarios/:id', (req, res) => {
    const id = req.params.id;
    const { nombre_usuario, email, contraseña, rol } = req.body;
    const sql = 'UPDATE Usuarios SET nombre_usuario = ?, email = ?, contraseña = ?, rol = ? WHERE id_usuario = ?';
    db.query(sql, [nombre_usuario, email, contraseña, rol, id], (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al actualizar el usuario' });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ error: 'Usuario no encontrado' });
        } else {
            res.json({ message: 'Usuario actualizado' });
        }
    });
});

// 5. Eliminar un usuario por ID
app.delete('/deleteUsuarios/:id', (req, res) => {
    const id = req.params.id;
    db.query('DELETE FROM Usuarios WHERE id_usuario = ?', [id], (err, result) => {
        if (err) {
            res.status(500).json({ error: 'Error al eliminar el usuario' });
        } else if (result.affectedRows === 0) {
            res.status(404).json({ error: 'Usuario no encontrado' });
        } else {
            res.json({ message: 'Usuario eliminado' });
        }
    });
});

// Ruta para manejar el inicio de sesión
app.post('/loginUsuario', (req, res) => {
    const { username, password } = req.body;

    // Verificar usuario en la base de datos
    db.query('SELECT * FROM Usuarios WHERE nombre_usuario = ? AND contraseña = ?', [username, password], (err, results) => {
        if (err) {
            return res.status(500).json({ error: 'Error al iniciar sesión' });
        }
        if (results.length === 0) {
            return res.status(401).json({ error: 'Credenciales inválidas' });
        }
        
        // Guardar información del usuario en la sesión
        req.session.userId = results[0].id_usuario;
        req.session.username = results[0].nombre_usuario;

        res.json({ message: 'Inicio de sesión exitoso' });
    });
});

// Verificar si hay una sesión activa
app.get('/session', (req, res) => {
    if (req.session.userId) {
        res.json({ loggedIn: true, username: req.session.username });
    } else {
        res.json({ loggedIn: false });
    }
});

// Ruta para cerrar sesión
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Error al cerrar sesión' });
        }
        // Responder con un estado de éxito
        res.json({ message: 'Sesión cerrada' });
    });
});

app.get('/isAdmin', (req, res) => {
    if (req.session.userId) {
        db.query('SELECT rol FROM Usuarios WHERE id_usuario = ?', [req.session.userId], (err, results) => {
            if (err) {
                return res.status(500).json({ error: 'Error al verificar rol' });
            }
            if (results[0]?.rol === 'admin') {
                return res.json({ isAdmin: true });
            }
            res.json({ isAdmin: false });
        });
    } else {
        res.json({ isAdmin: false });
    }
});

app.use(logger('dev'));

app.use(express.json());
// Servir archivos estáticos desde la carpeta client/html
app.use(express.static(path.join(process.cwd(), 'Client', 'html')));
app.use(express.static(path.join(process.cwd(), 'Client')));
// Ruta principal
app.get('/', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'Client', 'index.html'));
});
//ruta login
app.get('/login', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'Client', 'html', 'login.html'));
});
//ruta registro
app.get('/signup', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'Client', 'html', 'signup.html'));
});
//ruta contacto
app.get('/contacto', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'Client', 'html', 'contacto.html'));
})
//ruta nosotros
app.get('/nosotros', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'Client', 'html', 'nosotros.html'));
})
//ruta productos
app.get('/pagina-productos', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'Client', 'html', 'productos.html'));
})
//ruta producto
app.get('/ver_producto', (req, res) => {
    res.sendFile(path.join(process.cwd(), 'Client', 'html', 'ver_producto.html'));
})
// Manejo de errores en rutas no encontradas
app.use((req, res) => {
    res.status(404).sendFile(path.join(process.cwd(),'Client', 'html', 'error404.html'));
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});
